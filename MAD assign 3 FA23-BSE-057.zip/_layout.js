import { Tabs } from 'expo-router';
import { Text } from 'react-native';

export default function Layout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#25D366',
        tabBarInactiveTintColor: 'gray',
        headerStyle: { backgroundColor: '#25D366' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Chats',
          tabBarIcon: () => <Text style={{ fontSize: 20 }}>💬</Text>,
        }}
      />
      <Tabs.Screen
        name="StatusScreen"
        options={{
          title: 'Status',
          tabBarIcon: () => <Text style={{ fontSize: 20 }}>🔵</Text>,
        }}
      />
      <Tabs.Screen
        name="CallsScreen"
        options={{
          title: 'Calls',
          tabBarIcon: () => <Text style={{ fontSize: 20 }}>📞</Text>,
        }}
      />
      <Tabs.Screen
        name="ChatsScreen"
        options={{ href: null }} 
      />
    </Tabs>
  );
}
