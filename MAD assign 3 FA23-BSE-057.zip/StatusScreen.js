import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const statuses = [
  { id: '1', name: 'Mera Status', time: 'Abhi add karo', avatar: '➕' },
  { id: '2', name: 'Ali Raza', time: 'Aaj, 10:00 AM', avatar: '👨' },
  { id: '3', name: 'Sara Khan', time: 'Aaj, 9:00 AM', avatar: '👩' },
  { id: '4', name: 'Ahmed Bhai', time: 'Kal, 8:00 PM', avatar: '👦' },
];

export default function StatusScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={statuses}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.statusItem}>
            <Text style={styles.avatar}>{item.avatar}</Text>
            <View>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.time}>{item.time}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  statusItem: { flexDirection: 'row', padding: 15, borderBottomWidth: 1, borderBottomColor: '#f0f0f0', alignItems: 'center' },
  avatar: { fontSize: 40, marginRight: 15 },
  name: { fontWeight: 'bold', fontSize: 16 },
  time: { color: 'gray', fontSize: 13 },
});