import React from 'react';
import { View, Text, FlatList, StyleSheet, Image } from 'react-native';

const chats = [
  { id: '1', name: 'Ali Raza', message: 'Kal milte hain!', time: '10:30 AM', avatar: '👨' },
  { id: '2', name: 'Sara Khan', message: 'Okay, theek hai', time: '9:15 AM', avatar: '👩' },
  { id: '3', name: 'Ahmed Bhai', message: 'Assignment send karo', time: 'Kal', avatar: '👦' },
  { id: '4', name: 'Mama', message: 'Ghar kab aoge?', time: 'Kal', avatar: '👩' },
];

export default function ChatsScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.chatItem}>
            <Text style={styles.avatar}>{item.avatar}</Text>
            <View style={styles.chatInfo}>
              <View style={styles.row}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.time}>{item.time}</Text>
              </View>
              <Text style={styles.message}>{item.message}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  chatItem: { flexDirection: 'row', padding: 15, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  avatar: { fontSize: 40, marginRight: 15 },
  chatInfo: { flex: 1, justifyContent: 'center' },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  name: { fontWeight: 'bold', fontSize: 16 },
  time: { color: 'gray', fontSize: 12 },
  message: { color: 'gray', marginTop: 3 },
});