import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

const calls = [
  { id: '1', name: 'Ali Raza', type: '📞 Incoming', time: 'Aaj, 11:00 AM', avatar: '👨' },
  { id: '2', name: 'Sara Khan', type: '📵 Missed', time: 'Aaj, 9:30 AM', avatar: '👩' },
  { id: '3', name: 'Ahmed Bhai', type: '📤 Outgoing', time: 'Kal, 7:00 PM', avatar: '👦' },
];

export default function CallsScreen() {
  return (
    <View style={styles.container}>
      <FlatList
        data={calls}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.callItem}>
            <Text style={styles.avatar}>{item.avatar}</Text>
            <View>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={[styles.type, item.type.includes('Missed') && { color: 'red' }]}>
                {item.type}
              </Text>
            </View>
            <Text style={styles.time}>{item.time}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  callItem: { flexDirection: 'row', padding: 15, borderBottomWidth: 1, borderBottomColor: '#f0f0f0', alignItems: 'center' },
  avatar: { fontSize: 40, marginRight: 15 },
  name: { fontWeight: 'bold', fontSize: 16, flex: 1 },
  type: { color: 'green', fontSize: 13 },
  time: { color: 'gray', fontSize: 12 },
});