import React, { useState } from 'react';
import { 
  SafeAreaView, 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  FlatList, 
  StyleSheet 
} from 'react-native';

export default function App() {
  // State to store tasks
  const [task, setTask] = useState('');
  const [taskList, setTaskList] = useState([]);

  // Function to add a new task
  const addTask = () => {
    if (task.trim() === '') return; // Prevent empty tasks
    setTaskList([...taskList, task]);
    setTask(''); // Clear input
  };

  // Function to delete a task by index
  const deleteTask = (index) => {
    const updatedTasks = taskList.filter((_, i) => i !== index);
    setTaskList(updatedTasks);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>My To-Do List</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter a new task"
          value={task}
          onChangeText={setTask}
        />
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>Add</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={taskList}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.taskContainer}>
            <Text style={styles.taskText}>{item}</Text>
            <TouchableOpacity 
              style={styles.deleteButton} 
              onPress={() => deleteTask(index)}
            >
              <Text style={styles.deleteButtonText}>Delete</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e0f7fa', // soft teal background
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
    color: '#00796b', // dark teal
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 25,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3, // for android shadow
  },
  input: {
    flex: 1,
    paddingHorizontal: 15,
    fontSize: 16,
    borderRadius: 12,
    backgroundColor: '#fff',
    height: 50,
  },
  addButton: {
    marginLeft: 10,
    backgroundColor: '#00796b',
    paddingHorizontal: 20,
    justifyContent: 'center',
    borderRadius: 12,
    height: 50,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  taskContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#ffffff',
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  taskText: {
    fontSize: 18,
    color: '#004d40',
  },
  deleteButton: {
    backgroundColor: '#d32f2f',
    paddingHorizontal: 12,
    borderRadius: 10,
    justifyContent: 'center',
    height: 35,
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});